


CREATE TABLE muni (
    id_mun INT PRIMARY KEY,
    nomb_mun VARCHAR(100) NOT NULL,
    direc VARCHAR(255) NOT NULL
);

CREATE TABLE profe (
    id_prof INT PRIMARY KEY,
    nomb_prof VARCHAR(100) NOT NULL,
    tipo_con VARCHAR(50) NOT NULL CHECK (tipo_con IN ('Planta', 'Honoraria')),
    remu DECIMAL(10, 2) NOT NULL
);



CREATE TABLE estado_postulacion (
    id_estado INT PRIMARY KEY,
    nomb_estado VARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE acad (
    id_acad INT PRIMARY KEY,
    nomb_acad VARCHAR(100) NOT NULL,
    tipo_acad VARCHAR(50) NOT NULL ,
    id_dir INT,
    id_mun INT,
    FOREIGN KEY (id_dir) REFERENCES profe(id_prof),
    FOREIGN KEY (id_mun) REFERENCES muni(id_mun)
); 
CREATE TABLE curs (
    id_curs INT PRIMARY KEY,
    id_acad INT,
    nomb_curs VARCHAR(100) NOT NULL,
    durac INT NOT NULL,
    FOREIGN KEY (id_acad) REFERENCES acad(id_acad)
);
CREATE TABLE turno (
    id_turn INT PRIMARY KEY,
    id_prof INT,
    id_acad INT,
    hor_ini VARCHAR(15) NOT NULL,
    hor_fin VARCHAR(15),
    dia_sem VARCHAR(15) NOT NULL,
    FOREIGN KEY (id_prof) REFERENCES profe(id_prof),
    FOREIGN KEY (id_acad) REFERENCES acad(id_acad)
); 
CREATE TABLE proye (
    id_proy INT PRIMARY KEY,
    nomb_proy VARCHAR(100) NOT NULL,
    desc_pro VARCHAR(100),
    fech_ini DATE NOT NULL,
    fech_fin DATE NOT NULL
);
CREATE TABLE postu (
    id_post INT PRIMARY KEY,
    id_acad INT,
    id_proy INT,
    fech_pos DATE NOT NULL,
    id_estado INT NOT NULL,
    cuenta_banc VARCHAR(50) NOT NULL,
    FOREIGN KEY (id_acad) REFERENCES acad(id_acad),
    FOREIGN KEY (id_proy) REFERENCES proye(id_proy),
    FOREIGN KEY (id_estado) REFERENCES estado_postulacion(id_estado)
); CREATE TABLE insu (
    id_prof INT,
    id_curs INT,
    fech_asig DATE NOT NULL,
    PRIMARY KEY (id_prof, id_curs),
    FOREIGN KEY (id_prof) REFERENCES profe(id_prof),
    FOREIGN KEY (id_curs) REFERENCES curs(id_curs)
);



INSERT INTO muni (id_mun, nomb_mun, direc) VALUES (1, 'Municipio Valparaíso', 'Calle Los Poetas, Valparaíso');
INSERT INTO muni (id_mun, nomb_mun, direc) VALUES (2, 'Municipio Concepción', 'Avenida Libertador, Concepción');
INSERT INTO muni (id_mun, nomb_mun, direc) VALUES (3, 'Municipio La Serena', 'Calle del Mar, La Serena');
INSERT INTO muni (id_mun, nomb_mun, direc) VALUES (4, 'Municipio Temuco', 'Calle Alemania, Temuco');
INSERT INTO muni (id_mun, nomb_mun, direc) VALUES (5, 'Municipio Antofagasta', 'Avenida O’Higgins, Antofagasta');
INSERT INTO muni (id_mun, nomb_mun, direc) VALUES (6, 'Municipio Rancagua', 'Calle San Martín, Rancagua');
INSERT INTO muni (id_mun, nomb_mun, direc) VALUES (7, 'Municipio Chillán', 'Calle Los Ángeles, Chillán');


INSERT INTO profe (id_prof, nomb_prof, tipo_con, remu) VALUES (1, 'Juan Sanhueza', 'Planta', 600.00);
INSERT INTO profe (id_prof, nomb_prof, tipo_con, remu) VALUES (2, 'Pedro Lira', 'Honoraria', 500.00);
INSERT INTO profe (id_prof, nomb_prof, tipo_con, remu) VALUES (3, 'Raul Matamala', 'Planta', 800.00);
INSERT INTO profe (id_prof, nomb_prof, tipo_con, remu) VALUES (4, 'Cesar Lynch', 'Honoraria', 600.00);
INSERT INTO profe (id_prof, nomb_prof, tipo_con, remu) VALUES (5, 'Maria Antonia', 'Planta', 1100.00);
INSERT INTO profe (id_prof, nomb_prof, tipo_con, remu) VALUES (6, 'Juana del Carmen', 'Honoraria', 550.00);


INSERT INTO estado_postulacion (id_estado, nomb_estado) VALUES 
(1, 'Pendiente');
INSERT INTO estado_postulacion (id_estado, nomb_estado) VALUES 
(2, 'Aceptado');
INSERT INTO estado_postulacion (id_estado, nomb_estado) VALUES 
(3, 'Rechazado');
INSERT INTO estado_postulacion (id_estado, nomb_estado) VALUES 
(4, 'Finalizado');


INSERT INTO acad (id_acad, nomb_acad, tipo_acad, id_dir, id_mun) VALUES (1, 'Academia de Teatro Clásico', 'Teatro', 1, 1);
INSERT INTO acad (id_acad, nomb_acad, tipo_acad, id_dir, id_mun) VALUES (2, 'Escuela de Canto Moderno', 'Canto', 2, 1);
INSERT INTO acad (id_acad, nomb_acad, tipo_acad, id_dir, id_mun) VALUES (3, 'Centro de Danza Contemporánea', 'Baile', 3, 2);
INSERT INTO acad (id_acad, nomb_acad, tipo_acad, id_dir, id_mun) VALUES (4, 'Academia de Teatro Musical', 'Teatro', 4, 3);
INSERT INTO acad (id_acad, nomb_acad, tipo_acad, id_dir, id_mun) VALUES (5, 'Escuela de Canto y Música', 'Canto', 1, 2);
INSERT INTO acad (id_acad, nomb_acad, tipo_acad, id_dir, id_mun) VALUES (6, 'Instituto de Baile Clásico', 'Baile', 2, 3);


INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (1, 1, 'Cueca', 12);
INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (2, 1, 'Baile Folclórico', 16);
INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (3, 2, 'Danza del Norte', 10);
INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (4, 2, 'Técnicas Vocales', 14);
INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (5, 3, 'Danza Moderna', 20);
INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (6, 3, 'Baile de Salón', 18);
INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (7, 4, 'Teatro Musical', 15);
INSERT INTO curs (id_curs, id_acad, nomb_curs, durac) VALUES (8, 5, 'Canto y Piano', 12);






INSERT INTO turno (id_turn, id_prof, id_acad, hor_ini, hor_fin, dia_sem) VALUES (1, 1, 1, '08:00', '18:00', 'Lunes');
INSERT INTO turno (id_turn, id_prof, id_acad, hor_ini, hor_fin, dia_sem) VALUES (2, 2, 2, '09:00', '17:00', 'Martes');
INSERT INTO turno (id_turn, id_prof, id_acad, hor_ini, hor_fin, dia_sem) VALUES (3, 3, 3, '10:00', '14:00', 'Miércoles');
INSERT INTO turno (id_turn, id_prof, id_acad, hor_ini, hor_fin, dia_sem) VALUES (4, 4, 4, '11:00', '16:00', 'Jueves');
INSERT INTO turno (id_turn, id_prof, id_acad, hor_ini, hor_fin, dia_sem) VALUES (5, 5, 5, '12:00', '21:00', 'Viernes');
INSERT INTO turno (id_turn, id_prof, id_acad, hor_ini, hor_fin, dia_sem) VALUES (6, 6, 6, '13:00', '16:00', 'Lunes');


INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(1, 'Proyecto Azul', 'Pintamos calles a domicilio', TO_DATE('2024-11-20', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));
INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(2, 'Proyecto Salvando Ballenas', 'Salvando vidas marinas', TO_DATE('2024-02-28', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));
INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(3, 'Proyecto Mi Casa', 'Ahorro vivienda', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(4, 'Proyecto Todo o Nada', 'Para mi casa', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-10-01', 'YYYY-MM-DD'));
INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(5, 'Proyecto Las Líneas', 'Uniendo ciudades', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-11-02', 'YYYY-MM-DD'));
INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(6, 'Proyecto Sin Fin', 'Ahorro', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-11-01', 'YYYY-MM-DD'));
INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(7, 'Proyecto Rojo', 'Armando casas', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO proye (id_proy, nomb_proy, desc_pro, fech_ini, fech_fin) VALUES
(8, 'Proyecto Las Malandras', 'Mejoramiento de luminarias', TO_DATE('2024-08-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));


INSERT INTO postu (id_post, id_acad, id_proy, fech_pos, id_estado, cuenta_banc) VALUES (1, 1, 1, TO_DATE('2024-03-05', 'YYYY-MM-DD'), 1, '222222');
INSERT INTO postu (id_post, id_acad, id_proy, fech_pos, id_estado, cuenta_banc) VALUES (2, 2, 2, TO_DATE('2024-05-10', 'YYYY-MM-DD'), 2, '8733333');
INSERT INTO postu (id_post, id_acad, id_proy, fech_pos, id_estado, cuenta_banc) VALUES (3, 3, 3, TO_DATE('2024-08-15', 'YYYY-MM-DD'), 3, '1122443344');
INSERT INTO postu (id_post, id_acad, id_proy, fech_pos, id_estado, cuenta_banc) VALUES (4, 4, 4, TO_DATE('2024-09-20', 'YYYY-MM-DD'), 4, '6555554');


INSERT INTO insu (id_prof, id_curs, fech_asig) VALUES (1, 1, TO_DATE('2023-04-06', 'YYYY-MM-DD'));
INSERT INTO insu (id_prof, id_curs, fech_asig) VALUES (2, 2, TO_DATE('2023-03-06', 'YYYY-MM-DD'));
INSERT INTO insu (id_prof, id_curs, fech_asig) VALUES (3, 3, TO_DATE('2023-06-04', 'YYYY-MM-DD'));
INSERT INTO insu (id_prof, id_curs, fech_asig) VALUES (4, 4, TO_DATE('2023-02-03', 'YYYY-MM-DD'));
INSERT INTO insu (id_prof, id_curs, fech_asig) VALUES (5, 5, TO_DATE('2023-03-03', 'YYYY-MM-DD'));
INSERT INTO insu (id_prof, id_curs, fech_asig) VALUES (6, 6, TO_DATE('2023-04-04', 'YYYY-MM-DD'));






DROP TABLE insu CASCADE CONSTRAINTS;
DROP TABLE postu CASCADE CONSTRAINTS;
DROP TABLE turno CASCADE CONSTRAINTS;
DROP TABLE curs CASCADE CONSTRAINTS;
DROP TABLE acad CASCADE CONSTRAINTS;
DROP TABLE proye CASCADE CONSTRAINTS;
DROP TABLE estado_postulacion CASCADE CONSTRAINTS;
DROP TABLE profe CASCADE CONSTRAINTS;
DROP TABLE muni CASCADE CONSTRAINTS;

SELECT * FROM muni;
SELECT * FROM profe;
SELECT * FROM estado_postulacion;
SELECT * FROM acad;
SELECT * FROM curs;
SELECT * FROM turno;
SELECT * FROM proye;
SELECT * FROM postu;
SELECT * FROM insu;
